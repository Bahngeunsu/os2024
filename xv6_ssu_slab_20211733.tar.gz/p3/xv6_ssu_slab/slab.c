#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"

struct {
	struct spinlock lock;
	struct slab slab[NSLAB];
} stable;

int get_bit(int num, int i){
	return (num & (1<<i)) != 0;
}

int set_bit(int num, int i){
	return num | (1<<i);
}

unsigned int get_index(unsigned int n){
	if( n <= 16)
		return 0;

	unsigned count = 0;

	if(n && !(n & (n-1)))
		count -= 1;


	while(n != 0){
		n >>= 1;
		count += 1;
	}
	return (count - 4);
}

int clear_bit(int num, int i){
	int mask = ~(1<<i);
	return num & mask;
}

void slabinit(){
	struct slab *s;
	int size = 16;
	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		s->size = size;
		s->num_pages = 1;
		s->num_free_objects = 4096 / size;
		s->num_used_objects = 0;
		s->num_objects_per_page = 4096 / size;
		s->bitmap = kalloc();
		memset(s->bitmap, 0, 4096);
		s->page[0] = kalloc();
		int i;
		for (i=1; i <100; i++)
			s->page[i] = 0;
		size *= 2;
	}
	
}

char *kmalloc(int size){
	if(( size <= 0) || (size > 2048))
		return 0;

	int index = get_index(size);
//	acquire(&stable.lock);
	struct slab *s = &stable.slab[index];
	char *add;
	char *b;

	if (s->num_used_objects ==( s->num_objects_per_page* 100))
		return 0;
	
	int onum = 0;
	int pi;
	for(b = s->bitmap; b < s->bitmap + 4096; b++){
		int i ;
		for (i=0; i <8; i++){
			if(!get_bit(*b, i)){
				pi = onum / s->num_objects_per_page;
				if (s->page[pi] == 0){
					s->page[pi] = kalloc();
					s->num_pages +=1;
					s->num_free_objects += s->num_objects_per_page;
				}

				*b = set_bit(*b, i);
			
				s->num_free_objects -=1;
				s->num_used_objects +=1;
				
				add = s->page[pi] + s->size * (onum % s->num_objects_per_page);
//				release(&stable.lock);
				return add;
			}
			onum +=1;
		}
	}	
//	release(&stable.lock);
	return 0;
}

void kmfree(char *addr, int size){
//	acquire(&stable.lock);
	struct slab *s = &stable.slab[get_index(size)];
	

	int i;
	char *head=0;
	for (i=0; i<100; i++){
		if((s->page[i]<= addr) && (addr < (s->page[i] + 4096))){
			head = s->page[i];
			break;
		}
	}
	if (head==0)
		return;
	int onum;
	int offset;
	offset = (addr - head) / s->size;
	onum = (s->num_objects_per_page * i) + offset;
	char *b;
	b = s->bitmap +( onum / 8);
	if(get_bit(*b, onum%8) == 0)
		return;
	*b = clear_bit(*b, onum % 8);
	memset(addr, 1, s->size);	
	int empty = 1;
	int j;
	onum-=offset;
	for(j=0; j < s->num_objects_per_page; j++){
		b = s->bitmap + onum/8;
		if(get_bit(*b, onum%8) == 1){
			empty = 0;
			break;
		}
		onum++;
	}	

	if (empty){
		kfree(head);
		s->num_pages -=1;
		s->num_free_objects-= s->num_objects_per_page;
		s->page[i] = 0;
	}

	s->num_free_objects +=1;
	s->num_used_objects -=1;
	
//	release(&stable.lock);
}

/* Helper functions */
void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}

int numobj_slab(int slabid)
{
	return stable.slab[slabid].num_used_objects;
}

int numpage_slab(int slabid)
{
	return stable.slab[slabid].num_pages;
}
